package com.peisia.fantasytrip;

public class Player {
	static public String name;
	static public String cityId;
	static public long gold;
	static public long turn;
}
