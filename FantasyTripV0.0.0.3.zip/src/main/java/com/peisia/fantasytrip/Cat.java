package com.peisia.fantasytrip;
public class Cat {
	public int n = 0;
	public String s = "야옹";
}
