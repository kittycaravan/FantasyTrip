package com.peisia.jsp.fantasytrip.dto;

import com.peisia.c.util.Cw;

public class DtoPlayer {
	public String name;
	public String cityId;
	public long gold;
	public long turn;
	public DtoPlayer(String name, String cityId, long gold, long turn) {
		this.name = name;
		this.cityId = cityId;
		this.gold = gold;
		this.turn = turn;
	}
	public void info() {
    	Cw.wn("테스트 플레이어 이름:"+this.name);	
    	Cw.wn("테스트 플레이어 도시아이디:"+this.cityId);	
    	Cw.wn("테스트 플레이어 골드:"+this.gold);	
    	Cw.wn("테스트 플레이어 턴:"+this.turn);
	}
}
