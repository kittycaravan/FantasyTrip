package com.peisia.jsp.fantasytrip.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.peisia.jsp.fantasytrip.Db;
import com.peisia.jsp.fantasytrip.dto.DtoPlayer;

public class DaoPlayer {

	public DaoPlayer() {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public DtoPlayer getPlayer() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		DtoPlayer player = null;
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
			rs = st.executeQuery("select * from " + Db.TABLE_PLAYER);
			rs.next();
			String name = rs.getString("name");
			String cityId = rs.getString("CITY_ID");
			String gold = rs.getString("gold");
			String turn = rs.getString("turn");
			player = new DtoPlayer(name, cityId, Long.parseLong(gold), Long.parseLong(turn));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (st != null) {
					st.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return player;
	}
}