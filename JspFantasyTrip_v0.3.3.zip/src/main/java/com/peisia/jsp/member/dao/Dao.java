package com.peisia.jsp.member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.peisia.jsp.fantasytrip.Db;

public class Dao {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;	
	public Dao() {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	void connect() {
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	int update(String sql) {
		int r=0;
		try {
			r=st.executeUpdate(sql);
			return r;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.close();
		}
		return r;
	}
	void close() {
		try {
			if (st != null) {
				st.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
}