package com.peisia.jsp.member.dto;

public class DtoMember {
	public String id;
	public String pw;
	public DtoMember(String id, String pw) {
		super();
		this.id = id;
		this.pw = pw;
	}
	
}
