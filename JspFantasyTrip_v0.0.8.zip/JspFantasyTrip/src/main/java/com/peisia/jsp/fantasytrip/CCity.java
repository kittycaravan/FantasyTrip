package com.peisia.jsp.fantasytrip;

import com.peisia.c.util.Cw;

public class CCity {
	static public String id;
	static public String name;
	static public String nation;
	static public long devShop;
	static public long devArmy;
	static public int latitude; //위도. 북은 양수, 남은 음수로 ex. 1 = 북위 1도 ex. -1 = 남위 1도
	static public int longitude; //경도. 동은 양수, 서는 음수.
	
	static public String getLatitudeString() {
		String p;
		if(latitude > 0) {
			p = "북위:";
		} else if(latitude < 0) {
			p = "남위:";
		} else {	// 0이면
			p = "";
		}
		int abs = Math.abs(latitude);
		return p + abs;
	}
	static public String getLongitudeString() {
		String p;
		if(longitude > 0) {
			p = "동경:";
		} else {
			p = "서경:";
		}
		int abs = Math.abs(longitude);
		return p + abs;
	}
	static public void info() {
		Cw.wn("[로그]플레이어가 현재 있는 도시 id:" + CCity.id);
		Cw.wn("[로그]플레이어가 현재 있는 도시 이름:" + CCity.name);
		Cw.wn("[로그]플레이어가 현재 있는 도시 소속 국가:" + CCity.nation);
		Cw.wn("[로그]플레이어가 현재 있는 도시 발전도-상업:" + CCity.devShop);
		Cw.wn("[로그]플레이어가 현재 있는 도시 발전도-무장도:" + CCity.devArmy);
		Cw.wn("[로그]플레이어가 현재 있는 도시 위도:" + CCity.latitude);
		Cw.wn("[로그]플레이어가 현재 있는 도시 경도:" + CCity.longitude);
	}
}
