package com.peisia.jsp.fantasytrip.dto;

public class DtoCity {
	public String id;
	public String name;
	public String nation;
	public long devShop;
	public long devArmy;
	public int latitude; //위도. 북은 양수, 남은 음수로 ex. 1 = 북위 1도 ex. -1 = 남위 1도
	public int longitude; //경도. 동은 양수, 서는 음수. 
	public DtoCity(String id, String name, String nation, long devShop, long devArmy, int latitude, int longitude) {
		this.id = id;
		this.name = name;
		this.nation = nation;
		this.devShop = devShop;
		this.devArmy = devArmy;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	
}
