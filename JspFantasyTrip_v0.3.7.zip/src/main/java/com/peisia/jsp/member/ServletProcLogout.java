package com.peisia.jsp.member;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.peisia.c.util.Cw;
import com.peisia.jsp.member.dao.DaoMember;

public class ServletProcLogout extends HttpServlet {
	//단순 링크 이동으로 진입시 doGet이 호출됨. (doPost말고)
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.invalidate();
		//todo
		//쿠키 삭제
		Cookie c = new Cookie("CookiePeisiaAutoInputId", null);	//1.객체 또 만들긴 해야됨
		c.setMaxAge(0);	//쿠키 저장 초								//2.수명 0초로 세팅하고
		response.addCookie(c);	//쿠키 전송. 이걸해야 전송됨.			//3.전송도 해야함
		Cw.wn("삭제 쿠키 구움");		
		
		response.sendRedirect("/load_cookies.jsp");
	}
}
