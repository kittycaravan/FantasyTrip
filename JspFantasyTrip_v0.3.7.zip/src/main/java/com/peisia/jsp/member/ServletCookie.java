package com.peisia.jsp.member;

import java.io.IOException;

import com.peisia.c.util.Cw;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ServletCookie extends HttpServlet {
       
    public ServletCookie() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cookie[] cs = request.getCookies();
		String id = null;
		for(Cookie c:cs) {
			if(c.getName().equals("CookiePeisiaAutoInputId")) {
				id=c.getValue();
				Cw.wn("쿠키 CookiePeisiaAutoInputId 값 꺼냈음:"+id);
			}
		}
		//쿠기 값에 따른 분기
		if(id!=null) {
			response.sendRedirect("/index.jsp?id="+id);
		}else {
			response.sendRedirect("/index.jsp");
		}
	}
}