package com.peisia.jsp.fantasytrip.dao;

import java.util.ArrayList;

import com.peisia.c.util.Cw;
import com.peisia.db.Dao;
import com.peisia.db.Db;
import com.peisia.jsp.fantasytrip.dto.DtoCargo;

public class DaoCargo extends Dao{
	DtoCargo cargo = null;
	ArrayList<DtoCargo> cargos = null;
	public DaoCargo() {
		super();
	}
	public ArrayList<DtoCargo> getCargos(String playerId) {
		cargos = new ArrayList<>();
		super.connect();
		try {
			//서브 쿼리 써야함
//			select * from FT_INS_SHIP_CARGO where ship_id = (SELECT ship_id FROM FT_INS_SHIP where player_id=1);
			String sql = String.format(
					"select * from %s where ship_id = (SELECT ship_id FROM FT_INS_SHIP where player_id=%s)"
					,Db.TABLE_SHIP_CARGO,playerId);
			rs = st.executeQuery(sql);
			while(rs.next()) {
				String id=rs.getString("ID");
				String ship_id=rs.getString("SHIP_ID");
				String cargo_type=rs.getString("CARGO_TYPE");
				String goods_id=rs.getString("GOODS_ID");
				String purchases_price=rs.getString("PURCHASES_PRICE");
				String amount=rs.getString("AMOUNT");
				cargos.add(new DtoCargo(
						Integer.parseInt(id),
						Integer.parseInt(ship_id),
						cargo_type,
						Integer.parseInt(goods_id),
						Integer.parseInt(purchases_price),
						Integer.parseInt(amount)
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return cargos;
	}
	public void addCargo(int shipId,int goodsId,int price,int mount) {
		super.connect();
//		INSERT INTO FT_SHIP_CARGO (AC_ID,SHIP_ID,CARGO_TYPE,GOODS_ID,PURCHASES_PRICE,AMOUNT) VALUES ('NYANG4',1,'GOODS',1,100,1);
		String sql = String.format(
						"INSERT INTO "+Db.TABLE_SHIP_CARGO+" (SHIP_ID,CARGO_TYPE,GOODS_ID,PURCHASES_PRICE,AMOUNT) VALUES("
				+"%d,'%s',%d,%d,%d)"
				,1,"GOODS",goodsId,price,mount);
		Cw.wn("sql:"+sql);
		super.update(sql);
	}
}