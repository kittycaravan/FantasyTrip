package com.peisia.jsp.util;

public class Uj {
	static public String alertBack(String s) {
		//팝업 창은 브라우저에 따라 이슈가 있음. 팝업방지, 탭으로 출력 등.. 참고.
//		String html = "<script>window.open('/popup_test.html')</script>";
//		response.sendRedirect("/");	//이거 하면 위 스크립트 출력 안됨. *주의*				
		return "<script>alert('"+s+"'); history.go(-1); </script>";
	}
	static public String alert(String s,String successUrl) {
		return "<script>alert('"+s+"'); location.href='"+successUrl+"; </script>";
	}
}
