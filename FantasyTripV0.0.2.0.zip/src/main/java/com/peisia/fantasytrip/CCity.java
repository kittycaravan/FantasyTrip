package com.peisia.fantasytrip;

public class CCity {
	static public String id;
	static public String name;
	static public String nation;
	static public long devShop;
	static public long devArmy;
}
