package com.peisia.fantasytrip;

public class City {
	public String id;
	public String name;
	public String nation;
	public long devShop;
	public long devArmy;
	public City(String id, String name, String nation, long devShop, long devArmy) {
		this.id = id;
		this.name = name;
		this.nation = nation;
		this.devShop = devShop;
		this.devArmy = devArmy;
	}
	
}
