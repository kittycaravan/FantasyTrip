package com.peisia.jsp.member;

import java.io.IOException;
import java.io.PrintWriter;

import com.peisia.c.util.Cw;
import com.peisia.jsp.member.dao.DaoMember;
import com.peisia.jsp.util.Uj;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ServletProcRegMember extends HttpServlet {
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");	//이거 안하면 아래 alert 한글 깨짐
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");		
		String pw_re = request.getParameter("pw_re");

		if(pw.equals(pw_re)) {	//암호와 재확인 암호 비교
			DaoMember daoMember = new DaoMember();
			boolean isRegOk = daoMember.addMember(id, pw);	//중복확인도 처리해줌.
			if(isRegOk){	//회원가입 성공
				out.println(Uj.alertBack("회원가입 성공"));
			}else{
				out.println(Uj.alertBack("회원가입 실패"));				
			}
		}else{
			out.println(Uj.alertBack("암호와 재확인 암호x"));
		}
	}
}