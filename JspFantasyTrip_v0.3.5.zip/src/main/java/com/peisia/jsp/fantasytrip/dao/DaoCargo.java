package com.peisia.jsp.fantasytrip.dao;

import java.util.ArrayList;

import com.peisia.c.util.Cw;
import com.peisia.db.Dao;
import com.peisia.db.Db;
import com.peisia.jsp.fantasytrip.dto.DtoCargo;

public class DaoCargo extends Dao{
	DtoCargo cargo = null;
	ArrayList<DtoCargo> cargos = null;
	public DaoCargo() {
		super();
	}
	public ArrayList<DtoCargo> getCargos(String acId) {
		cargos = new ArrayList<>();
		super.connect();
		try {
			rs = st.executeQuery("select * from " + Db.TABLE_SHIP_CARGO + " where AC_ID='"+acId+"'");
			while(rs.next()) {
				String id=rs.getString("ID");
				String ac_id=rs.getString("AC_ID");
				String ship_id=rs.getString("SHIP_ID");
				String cargo_type=rs.getString("CARGO_TYPE");
				String goods_id=rs.getString("GOODS_ID");
				String purchases_price=rs.getString("PURCHASES_PRICE");
				String amount=rs.getString("AMOUNT");
				cargos.add(new DtoCargo(
						Integer.parseInt(id),
						ac_id,
						Integer.parseInt(ship_id),
						cargo_type,
						Integer.parseInt(goods_id),
						Integer.parseInt(purchases_price),
						Integer.parseInt(amount)
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return cargos;
	}
	public void addCargo(String acId,int shipId,int goodsId,int price,int mount) {
		super.connect();
//		INSERT INTO FT_SHIP_CARGO (AC_ID,SHIP_ID,CARGO_TYPE,GOODS_ID,PURCHASES_PRICE,AMOUNT) VALUES ('NYANG4',1,'GOODS',1,100,1);
		String sql = 
				"INSERT INTO "+Db.TABLE_SHIP_CARGO+" (AC_ID,SHIP_ID,CARGO_TYPE,GOODS_ID,PURCHASES_PRICE,AMOUNT) VALUES("
				+"'"+acId+"',"+shipId+",'GOODS',"+goodsId+","+price+","+mount+")";				
		Cw.wn("sql:"+sql);
		super.update(sql);
	}
}