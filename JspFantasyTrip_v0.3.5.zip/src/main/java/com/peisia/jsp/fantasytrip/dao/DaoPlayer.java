package com.peisia.jsp.fantasytrip.dao;

import com.peisia.c.util.Cw;
import com.peisia.db.Dao;
import com.peisia.db.Db;
import com.peisia.jsp.fantasytrip.dto.DtoPlayer;

public class DaoPlayer extends Dao{
	DtoPlayer player = null;
	public DaoPlayer() {
		super();
	}
	public DtoPlayer getPlayer() {
		super.connect();
		try {
			rs = st.executeQuery("select * from " + Db.TABLE_PLAYER);
			rs.next();
			String id = rs.getString("id");
			String name = rs.getString("name");
			String cityId = rs.getString("CITY_ID");
			String gold = rs.getString("gold");
			String turn = rs.getString("turn");
			player = new DtoPlayer(id, name, cityId, Long.parseLong(gold), Long.parseLong(turn));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return player;
	}
	public void setCity(String destinationCityId) {
		super.connect();
		String sql = "UPDATE ft_player set city_id='" + destinationCityId + "'";
		Cw.wn("sql:"+sql);
		super.update(sql);
	}
	public void setGold(long updateGold) {
		super.connect();
		String sql = "UPDATE ft_player set gold=" + updateGold;	//주의. 숫자 데이터 칼럼임.
		Cw.wn("sql:"+sql);
		super.update(sql);
	}
}