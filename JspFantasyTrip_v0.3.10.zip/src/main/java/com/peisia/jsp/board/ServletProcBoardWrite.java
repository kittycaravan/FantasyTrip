package com.peisia.jsp.board;

import java.io.IOException;

import com.peisia.c.util.Cw;
import com.peisia.db.Db;
import com.peisia.jsp.board.dao.DaoPost;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ServletProcBoardWrite extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DaoPost daoPost = new DaoPost();
		daoPost.writePost(
				Db.TABLE_PS_BOARD_FREE,
				request.getParameter("title"),
				request.getParameter("id"),
				request.getParameter("text"));		
		response.sendRedirect("/board/list.jsp");
	}
}