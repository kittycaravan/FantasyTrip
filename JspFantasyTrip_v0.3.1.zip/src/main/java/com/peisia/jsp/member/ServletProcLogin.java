package com.peisia.jsp.member;

import java.io.IOException;

import com.peisia.c.util.Cw;
import com.peisia.jsp.member.dao.DaoMember;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class ServletProcLogin extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		DaoMember daoMember = new DaoMember();
		boolean isLoginOk = daoMember.loginMember(id, pw);
		if (isLoginOk) { // 로그인 성공
			Cw.wn("로그인 성공");
			// 로그인처리
			HttpSession session = request.getSession();
			session.setAttribute("keyId", id);
			// session.setMaxInactiveInterval(60*5); //5분
			session.setMaxInactiveInterval(10);
		} else {
			Cw.wn("로그인 실패");
		}
		response.sendRedirect("/index.jsp");
	}
}