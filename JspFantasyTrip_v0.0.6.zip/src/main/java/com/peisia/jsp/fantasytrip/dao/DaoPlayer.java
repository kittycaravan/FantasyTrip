package com.peisia.jsp.fantasytrip.dao;

public class DaoPlayer {
	
}
