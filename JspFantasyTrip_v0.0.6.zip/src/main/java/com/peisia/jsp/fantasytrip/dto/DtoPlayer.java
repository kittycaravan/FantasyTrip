package com.peisia.jsp.fantasytrip.dto;

public class DtoPlayer {
	static public String name;
	static public String cityId;
	static public long gold;
	static public long turn;
}
