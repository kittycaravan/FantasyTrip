package com.peisia.jsp.fantasytrip;

public class CCity {
	static public String id;
	static public String name;
	static public String nation;
	static public long devShop;
	static public long devArmy;
	static public int latitude; //위도. 북은 양수, 남은 음수로 ex. 1 = 북위 1도 ex. -1 = 남위 1도
	static public int longitude; //경도. 동은 양수, 서는 음수.
	
	static public String getLatitudeString() {
		String p;
		if(latitude > 0) {
			p = "북위:";
		} else if(latitude < 0) {
			p = "남위:";
		} else {	// 0이면
			p = "";
		}
		int abs = Math.abs(latitude);
		return p + abs;
	}
	static public String getLongitudeString() {
		String p;
		if(longitude > 0) {
			p = "동경:";
		} else {
			p = "서경:";
		}
		int abs = Math.abs(longitude);
		return p + abs;
	}
}
