package com.peisia.jsp.member.dao;

import com.peisia.c.util.Cw;
import com.peisia.jsp.fantasytrip.Db;
import com.peisia.jsp.member.dto.DtoMember;

public class DaoMember extends Dao{
	DtoMember member = null;
	public DaoMember() {
		super();
	}
	/* 중복회원체크 */	
	public boolean isMember(String id) {
		super.connect();
		String sql = "SELECT COUNT(*) FROM "+Db.TABLE_PS_MEMBER+" WHERE PS_ID='"+id+"'";
		Cw.wn("sql:"+sql);
		try {
			rs = st.executeQuery(sql);
			rs.next();
			String c = rs.getString("COUNT(*)");
			if(c.equals("1")) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return false;		
	}
	/* 회원가입 */
	public boolean addMember(String id,String pw) {
		int r=0;	//결과 반영 수 저장.
		if(isMember(id)) {	//중복이면 리턴 false
			return false;
		}else {	//중복 아니면 회원가입처리
			super.connect();
			String sql = 
					"INSERT INTO "+Db.TABLE_PS_MEMBER+" (PS_ID,PS_PW) VALUES ('"+id+"','"
					+pw+"')";
			Cw.wn("sql:"+sql);
			r = super.update(sql);			
		}
		if(r==1) {
			return true;
		}else {
			return false;
		}
	}
	public boolean loginMember(String id,String pw) {
		super.connect();
		String sql = 
				"SELECT COUNT(*) FROM "+Db.TABLE_PS_MEMBER+" WHERE PS_ID='"+id+"' AND PS_PW='"
						+pw+"'";
		Cw.wn("sql:"+sql);
		try {
			rs = st.executeQuery(sql);
			rs.next();
			String c = rs.getString("COUNT(*)");
			if(c.equals("1")) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return false;
	}
}