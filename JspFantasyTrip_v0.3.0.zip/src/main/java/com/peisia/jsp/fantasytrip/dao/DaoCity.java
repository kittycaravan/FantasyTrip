package com.peisia.jsp.fantasytrip.dao;

import java.sql.DriverManager;
import java.util.ArrayList;

import com.peisia.jsp.fantasytrip.Db;
import com.peisia.jsp.fantasytrip.dto.DtoCity;

public class DaoCity extends Dao{
	DtoCity city;
	public DaoCity() {
		super();
	}

	public DtoCity getCity(String playerCityId) {
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
			rs = st.executeQuery("select * from " + Db.TABLE_CITY + " where ID ='" + playerCityId + "'");
			rs.next();
			String id = rs.getString("ID");
			String name = rs.getString("NAME");
			String nation = rs.getString("NATION");
			String devShop = rs.getString("DEV_SHOP");
			String devArmy = rs.getString("DEV_ARMY");
			String latitude = rs.getString("LATITUDE");
			String longitude = rs.getString("LONGITUDE");
			city = new DtoCity(
					id, 
					name, 
					nation, 
					Long.parseLong(devShop),
					Long.parseLong(devArmy), 
					Integer.parseInt(latitude),
					Integer.parseInt(longitude)
			);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return city;
	}
	public ArrayList<DtoCity> getCities() {
		ArrayList<DtoCity> cities = new ArrayList<>();
		DtoCity city = null;
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
			rs = st.executeQuery("select * from " + Db.TABLE_CITY);
			while(rs.next()) {
				String id = rs.getString("ID");
				String name = rs.getString("NAME");
				String nation = rs.getString("NATION");
				String devShop = rs.getString("DEV_SHOP");
				String devArmy = rs.getString("DEV_ARMY");
				String latitude = rs.getString("LATITUDE");
				String longitude = rs.getString("LONGITUDE");
				city = new DtoCity(
						id, 
						name, 
						nation, 
						Long.parseLong(devShop),
						Long.parseLong(devArmy), 
						Integer.parseInt(latitude),
						Integer.parseInt(longitude)
						);
				cities.add(city);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return cities;
	}
}