package com.peisia.jsp.fantasytrip.dto;

public class DtoCargo {
	public int id;
	public String ac_id;
	public int ship_id;
	public String cargo_type;
	public int goods_id;
	public int purchases_price;
	public int amount;
	public DtoCargo(int id, String ac_id, int ship_id, String cargo_type, int goods_id, int purchases_price,
			int amount) {
		super();
		this.id = id;
		this.ac_id = ac_id;
		this.ship_id = ship_id;
		this.cargo_type = cargo_type;
		this.goods_id = goods_id;
		this.purchases_price = purchases_price;
		this.amount = amount;
	}
}