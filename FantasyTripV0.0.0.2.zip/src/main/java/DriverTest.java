import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DriverTest {
	public static void main(String[] args) {
		Connection con;
		try {
			Class.forName("oracle.jdbc.OracleDriver").newInstance();
			con=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:orcl","nyang4","nyang4");
			System.out.println("성공");
		} catch (SQLException e){
			System.out.println("sql 익셉션:"+e);
		} catch (Exception e) {
			System.out.println("익셉션:"+e);
		}
		
	}
}
