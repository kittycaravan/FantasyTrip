package com.peisia.jsp.member;

import java.io.IOException;

import com.peisia.c.util.Cw;
import com.peisia.jsp.member.dao.DaoMember;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class ServletProcLogin extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String auto_input_id = request.getParameter("auto_input_id");

		DaoMember daoMember = new DaoMember();
		boolean isLoginOk = daoMember.loginMember(id, pw);
		if (isLoginOk) { // 로그인 성공
			Cw.wn("로그인 성공");
			// 로그인처리
			HttpSession session = request.getSession();
			session.setAttribute("keyId", id);
			// session.setMaxInactiveInterval(60*5); //5분
			session.setMaxInactiveInterval(10);
			
			//id 기억 처리
			if(auto_input_id!=null&&auto_input_id.equals("on")) {
				Cookie c = new Cookie("CookiePeisiaAutoInputId", id);	//CookiePeisiaAutoInputId라는 이름으로 id를 쿠키를 굽고..
				c.setMaxAge(30);	//쿠키 저장 초
				response.addCookie(c);	//쿠키 전송. 이걸해야 전송됨.
				Cw.wn("쿠키 구움");
			}			
		} else {
			Cw.wn("로그인 실패");
		}
		response.sendRedirect("/index.jsp");
	}
}