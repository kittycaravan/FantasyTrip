package com.peisia.jsp.fantasytrip.controller;

import java.io.IOException;

import com.peisia.c.util.Cw;
import com.peisia.jsp.fantasytrip.dao.DaoPlayer;
import com.peisia.jsp.fantasytrip.dto.DtoPlayer;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ftft/*")
public class ControllerFt extends HttpServlet {
	String nextPage;
	HttpSession session;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session = req.getSession();
		String action = req.getPathInfo();
		Cw.wn("action:"+action);
		if(action!=null) {
			switch (action) {
			case "/inn":
				nextPage = "/ft/inn2.jsp";
				DaoPlayer daoPlayer=new DaoPlayer();
				DtoPlayer player=daoPlayer.getPlayer();
				session.setAttribute("player", player);	//세션에 플레이어 정보를 넣고 쓰게 함.
				break;
			default:
				nextPage = "/ft/inn2.jsp";
				break;
			}
		}
		RequestDispatcher d = req.getRequestDispatcher(nextPage);
		d.forward(req,resp);
	}
}
