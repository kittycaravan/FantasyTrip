package com.peisia.jsp.fantasytrip.dto;

public class DtoGoods {
	public int id;
	public String name;
	public String type;
	public String type_x;
	public int specialty_lv;
	public int price_producer;
	public int price_selling;
	public int distance_weight;
	public int specialty_weight;
	public int change_range;
	public int amount;
	public DtoGoods(int id, String name, String type, String type_x, int specialty_lv, int price_producer,
			int price_selling, int distance_weight, int specialty_weight, int change_range, int amount) {
		this.id = id;
		this.name = name;
		this.type = type;
		this.type_x = type_x;
		this.specialty_lv = specialty_lv;
		this.price_producer = price_producer;
		this.price_selling = price_selling;
		this.distance_weight = distance_weight;
		this.specialty_weight = specialty_weight;
		this.change_range = change_range;
		this.amount = amount;
	}
	
	
}
