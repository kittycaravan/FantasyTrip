package com.peisia.jsp.fantasytrip.dto;

import com.peisia.c.util.Cw;

public class DtoPlayer {
	public String id;
	public String name;
	public String cityId;
	public long gold;
	public long turn;
	public DtoPlayer(String id, String name, String cityId, long gold, long turn) {
		super();
		this.id = id;
		this.name = name;
		this.cityId = cityId;
		this.gold = gold;
		this.turn = turn;
	}

	public void info() {
    	Cw.wn("플레이어 id:"+this.id);	
    	Cw.wn("플레이어 이름:"+this.name);	
    	Cw.wn("플레이어 도시아이디:"+this.cityId);	
    	Cw.wn("플레이어 골드:"+this.gold);	
    	Cw.wn("플레이어 턴:"+this.turn);
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getCityId() {
		return cityId;
	}

	public long getGold() {
		return gold;
	}

	public long getTurn() {
		return turn;
	}
	
	
	
}
