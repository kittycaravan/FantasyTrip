package com.peisia.jsp.fantasytrip.dao;

import java.sql.DriverManager;
import java.util.ArrayList;

import com.peisia.db.Dao;
import com.peisia.db.Db;
import com.peisia.jsp.fantasytrip.dto.DtoGoods;

public class DaoGoods extends Dao{
	DtoGoods goods;
	ArrayList<DtoGoods> goodsList;
	public DaoGoods() {
		super();
	}

	public DtoGoods getGoods(int goodsId) {
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
			rs = st.executeQuery("select * from " + Db.TABLE_GOODS + " where ID =" + goodsId);
			rs.next();
			String id = rs.getString("ID");
			String name = rs.getString("NAME");
			String type = rs.getString("TYPE");
			String type_x = rs.getString("TYPE_X");
			String specialty_lv = rs.getString("SPECIALTY_LV");
			String price_producer = rs.getString("PRICE_PRODUCER");
			String price_selling = rs.getString("PRICE_SELLING");
			String distance_weight = rs.getString("DISTANCE_WEIGHT");
			String specialty_weight = rs.getString("SPECIALTY_WEIGHT");
			String change_range = rs.getString("CHANGE_RANGE");
			String amount = rs.getString("AMOUNT");
			goods = new DtoGoods(
					Integer.parseInt(id),
					name,
					type,
					type_x,
					Integer.parseInt(specialty_lv),
					Integer.parseInt(price_producer),
					Integer.parseInt(price_selling),
					Integer.parseInt(distance_weight),
					Integer.parseInt(specialty_weight),
					Integer.parseInt(change_range),
					Integer.parseInt(amount)
			);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return goods;
	}
	public ArrayList<DtoGoods> getGoodsList() {
		goodsList = new ArrayList<>();
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
			rs = st.executeQuery("select * from " + Db.TABLE_GOODS);
			while(rs.next()) {
				String id = rs.getString("ID");
				String name = rs.getString("NAME");
				String type = rs.getString("TYPE");
				String type_x = rs.getString("TYPE_X");
				String specialty_lv = rs.getString("SPECIALTY_LV");
				String price_producer = rs.getString("PRICE_PRODUCER");
				String price_selling = rs.getString("PRICE_SELLING");
				String distance_weight = rs.getString("DISTANCE_WEIGHT");
				String specialty_weight = rs.getString("SPECIALTY_WEIGHT");
				String change_range = rs.getString("CHANGE_RANGE");
				String amount = rs.getString("AMOUNT");
				goods = new DtoGoods(
						Integer.parseInt(id),
						name,
						type,
						type_x,
						Integer.parseInt(specialty_lv),
						Integer.parseInt(price_producer),
						Integer.parseInt(price_selling),
						Integer.parseInt(distance_weight),
						Integer.parseInt(specialty_weight),
						Integer.parseInt(change_range),
						Integer.parseInt(amount)
				);
				goodsList.add(goods);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return goodsList;
	}
}