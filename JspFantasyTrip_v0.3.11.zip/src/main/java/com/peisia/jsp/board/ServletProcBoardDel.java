package com.peisia.jsp.board;

import java.io.IOException;

import com.peisia.db.Db;
import com.peisia.jsp.board.dao.DaoPost;
import com.peisia.jsp.board.dto.DtoPost;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ServletProcBoardDel extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int no = Integer.parseInt(request.getParameter("no"));
		DaoPost daoPost = new DaoPost();
		daoPost.deletePost(Db.TABLE_PS_BOARD_FREE,no);
		response.sendRedirect("/board/list.jsp");
	}
}
