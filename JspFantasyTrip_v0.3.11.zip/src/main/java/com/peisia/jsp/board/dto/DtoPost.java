package com.peisia.jsp.board.dto;

public class DtoPost {
	private int no;
	private String title;
	private String id;
	private String datetime;
	private int hit;
	private String text;
	private int replyCount;
	private int replyOri;

	public DtoPost(int no, String title, String id, String datetime, int hit, String text, int replyCount,
			int replyOri) {
		super();
		this.no = no;
		this.title = title;
		this.id = id;
		this.datetime = datetime;
		this.hit = hit;
		this.text = text;
		this.replyCount = replyCount;
		this.replyOri = replyOri;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getReplyCount() {
		return replyCount;
	}
	public void setReplyCount(int replyCount) {
		this.replyCount = replyCount;
	}
	public int getReplyOri() {
		return replyOri;
	}
	public void setReplyOri(int replyOri) {
		this.replyOri = replyOri;
	}
	
}

