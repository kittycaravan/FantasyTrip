package com.peisia.jsp.board.dao;

import java.util.ArrayList;

import com.peisia.c.util.Cw;
import com.peisia.db.Dao;
import com.peisia.db.Db;
import com.peisia.jsp.board.dto.DtoPost;

public class DaoPost extends Dao{
	//c
	public void writePost(String board, String title,String id,String text) {
		super.connect();
		int c=0;
//		insert into ps_board_free (b_title,b_id,b_text) values ('야옹','cat','aaa');
		String sql = String.format(
				"INSERT INTO %s (B_TITLE,B_ID,B_TEXT) VALUES('%s','%s','%s')"
				,board,title,id,text
				);
		Cw.wn("sql:"+sql);
		super.update(sql);
	}
	//r
	public ArrayList<DtoPost> getList(String board) {
		ArrayList<DtoPost> posts=new ArrayList<>();
		DtoPost post = null;
		super.connect();
//		select * from ps_board_free where b_no=2;
		String sql = String.format(
				"SELECT * FROM %s"
				,board
				);
		Cw.wn("sql:"+sql);
		try {
			rs = st.executeQuery(sql);
			while(rs.next()) {
				post=new DtoPost(
						rs.getInt("b_no"),
						rs.getString("b_title"), 
						rs.getString("b_id"),
						rs.getString("b_datetime"),
						rs.getInt("b_hit"),
						rs.getString("b_text"),
						rs.getInt("b_reply_count"),
						rs.getInt("b_reply_ori"));
				posts.add(post);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return posts;		
	}
	//r
	public DtoPost getPost(String board,int no) {
		DtoPost post=null;
		super.connect();
//		select * from ps_board_free where b_no=2;
		String sql = String.format(
				"SELECT * FROM %s WHERE B_NO=%d"
				,board,no
				);
		Cw.wn("sql:"+sql);
		try {
			rs = st.executeQuery(sql);
			rs.next();
			post=new DtoPost(
					rs.getInt("b_no"),
					rs.getString("b_title"), 
					rs.getString("b_id"),
					rs.getString("b_datetime"),
					rs.getInt("b_hit"),
					rs.getString("b_text"),
					rs.getInt("b_reply_count"),
					rs.getInt("b_reply_ori"));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			super.close();
		}
		return post;
	}
	//u
	public void updatePost(String board,String title,String no,String text) {
		super.connect();
//		update ps_board_free set b_title='bb',b_text='bbbb';
		String sql = String.format(
				"UPDATE %s SET B_TITLE='%s',B_TEXT='%s' where B_NO=%s"
				,board,title,text,no
				);
		Cw.wn("sql:"+sql);
		super.update(sql);		
	}
	//d
	public void deletePost(String board,int no) {
		super.connect();
//		delete from ps_board_free where b_no=1;
		String sql = String.format(
				"DELETE FROM %s WHERE B_NO=%d"
				,board,no
				);
		Cw.wn("sql:"+sql);
		super.update(sql);		
	}	
}