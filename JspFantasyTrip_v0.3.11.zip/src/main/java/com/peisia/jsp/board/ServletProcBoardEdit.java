package com.peisia.jsp.board;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.peisia.db.Db;
import com.peisia.jsp.board.dao.DaoPost;

public class ServletProcBoardEdit extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DaoPost daoPost = new DaoPost();
		daoPost.updatePost(
				Db.TABLE_PS_BOARD_FREE,
				request.getParameter("title"),
				request.getParameter("no"),
				request.getParameter("text"));		
		response.sendRedirect("/board/list.jsp");		
	}

}
