package com.peisia.jsp.fantasytrip.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.peisia.jsp.fantasytrip.Db;
import com.peisia.jsp.fantasytrip.dto.DtoCity;

public class DaoCity {

	public DaoCity() {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public DtoCity getCity(String playerCityId) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		DtoCity city = null;
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
			rs = st.executeQuery("select * from " + Db.TABLE_CITY + " where ID ='" + playerCityId + "'");
			rs.next();
			String id = rs.getString("ID");
			String name = rs.getString("NAME");
			String nation = rs.getString("NATION");
			String devShop = rs.getString("DEV_SHOP");
			String devArmy = rs.getString("DEV_ARMY");
			String latitude = rs.getString("LATITUDE");
			String longitude = rs.getString("LONGITUDE");
			city = new DtoCity(
					id, 
					name, 
					nation, 
					Long.parseLong(devShop),
					Long.parseLong(devArmy), 
					Integer.parseInt(latitude),
					Integer.parseInt(longitude)
			);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (st != null) {
					st.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return city;
	}
	public ArrayList<DtoCity> getCities() {
		ArrayList<DtoCity> cities = new ArrayList<>();
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		DtoCity city = null;
		try {
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st=con.createStatement();
			rs = st.executeQuery("select * from " + Db.TABLE_CITY);
			while(rs.next()) {
				String id = rs.getString("ID");
				String name = rs.getString("NAME");
				String nation = rs.getString("NATION");
				String devShop = rs.getString("DEV_SHOP");
				String devArmy = rs.getString("DEV_ARMY");
				String latitude = rs.getString("LATITUDE");
				String longitude = rs.getString("LONGITUDE");
				city = new DtoCity(
						id, 
						name, 
						nation, 
						Long.parseLong(devShop),
						Long.parseLong(devArmy), 
						Integer.parseInt(latitude),
						Integer.parseInt(longitude)
						);
				cities.add(city);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (st != null) {
					st.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cities;
	}
}