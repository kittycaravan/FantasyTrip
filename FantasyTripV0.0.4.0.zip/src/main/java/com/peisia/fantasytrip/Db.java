package com.peisia.fantasytrip;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Db {
	static public Connection con = null;
	static public Statement stmt = null;
	static public ResultSet rs = null;
	static public int result = 0;
	
	static public void connectDb() throws Exception{
		Class.forName("oracle.jdbc.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:orcl","ft","ft");
		stmt=con.createStatement();
	}
	static public void disconnectDb() throws Exception{
		rs.close();		//db 연결 종료처리
		stmt.close();	//db 연결 종료처리
		con.close();	//db 연결 종료처리
	}	
}
